<?php

birch_ns( 'appointer.model.cpt', function( $ns ) {

	} );
